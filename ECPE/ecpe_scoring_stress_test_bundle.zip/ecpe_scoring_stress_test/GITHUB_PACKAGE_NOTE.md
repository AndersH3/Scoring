# Compact GitHub bundle

This GitHub edition omits only `ecpe_results/run_state.rds` from the original
completed-results bundle to stay within the repository connector's per-file
transfer limit. The RDS held bootstrap draws, audit scores, split identifiers and
random-number states; it was not needed to read the report, plots or CSV results.

The retained `ecpe_results/output_manifest.csv` records the original complete run,
so its `run_state.rds` row intentionally describes a file that is not present in
this compact archive. Run `ecpe_scoring_stress_test.R` to generate a fresh complete
results directory, including a new `run_state.rds`.
