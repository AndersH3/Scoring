list(out = "ecpe_results", seed = 20260901L, bootstrap = 500L, 
    repeats = 100L, permutations = 500L, folds = 5L, train_fraction = 0.7, 
    sizes = c(50L, 100L, 250L, 500L, 1000L, 2000L), score_type = "rest", 
    quick = FALSE, self_test = FALSE, help = FALSE)
