# ECPE scoring report — source and reproduction package

The separately published report is `ECPE_scoring_report.pdf`. Its editable source
is `ECPE_scoring_report.tex`, with `references.bib` and the figures in `figures/`.
It was written for Anders Hellström's New Scoring System project. The prominent
cover disclosure and final appendix explain substantial OpenAI ChatGPT involvement.

## Evidence and versions

- Primary evidence: the user's completed ECPE stress-test archive, not a newly substituted run.
- Scoring definition: `code/item_analysis_reference.r`, pinned Git blob
  `a336d1b3d9964bd5f2e0f90f214e15d540be827d`.
- Stress-test implementation: `code/ecpe_scoring_stress_test.R`, version 1.0.0.
- Primary environment: R 4.6.1, edmdata 1.3.0, Hmisc 5.2-6; see `data/sessionInfo.txt`.
- Supplementary analyses: endpoint-preserving monotone quadratic and 4,000 independent
  appended-item simulations, explicitly separated in `supplementary/`.
- Historical PISA findings are transcribed from the user-supplied earlier report and
  were not rerun for this deliverable.

`data/output_manifest.csv` describes the ORIGINAL run directory. Some original files
are not duplicated here, and the original program has been placed under `code/`.
It is retained as provenance for that run, not as a manifest of this compact package.

This compact GitHub edition omits the separately published PDF, `data/run_state.rds`,
`data/contamination_replicates.csv` and `supplementary/null_item_replicates.csv` to
stay within the repository connector's per-file transfer limit. Their derived
figures and summary tables remain included.
Run the supplied stress-test and supplementary programs to recreate fresh simulation
state and replicate-level output.

## Build the report

Requirements: XeLaTeX and BibTeX, KOMA-Script, fontspec, unicode-math, mathtools,
microtype, tcolorbox, tabularray, natbib, graphicx, xcolor, enumitem, listings,
placeins, float, xurl, babel, scrlayer-scrpage, hyperref and bookmark. The report
uses Latin Modern Roman, Sans, Mono and Math, normally included with TeX Live.

From this directory:

```sh
latexmk -xelatex -interaction=nonstopmode -halt-on-error ECPE_scoring_report.tex
```

Alternatively, the explicit sequence is:

```sh
xelatex -interaction=nonstopmode -halt-on-error ECPE_scoring_report.tex
bibtex ECPE_scoring_report
xelatex -interaction=nonstopmode -halt-on-error ECPE_scoring_report.tex
xelatex -interaction=nonstopmode -halt-on-error ECPE_scoring_report.tex
```

The supplied figures and tables allow compilation without rerunning any simulations.
The Python and TeX versions used during preparation are in `build_environment.txt`.

## Reproduce the original stress experiment

```sh
Rscript -e 'install.packages("edmdata", repos="https://cloud.r-project.org")'
Rscript code/ecpe_scoring_stress_test.R --out fresh_ecpe_results
```

Use a new or empty output directory. Linux filenames are case-sensitive: the
supplied filename ends in uppercase `.R`. Optional Hmisc is used for an additional
self-test when installed; the implementation requires only edmdata as an add-on.
See `code/ECPE_STRESS_TEST_README.md` and `--help` for all controls. The pinned
application snapshot is included as a specification reference and is not needed
by the standalone stress-test script.

## Reproduce the supplementary analyses and report graphics

Run from the bundle root:

```sh
Rscript code/ecpe_supplementary.R
python3 code/build_figures.py
```

The R script normally reads the original `data/run_state.rds`, which is omitted from
this compact GitHub edition. First rerun the stress test and copy its `run_state.rds`
into `data/` if exact regeneration is needed. The supplementary program overwrites
only its named outputs. Its independent-item simulation uses seed 20260902, four
success probabilities (0.001, 0.01, 0.05 and 0.5), and 1,000 replicates each. It
examines calibration weight allocation, not audit performance or known proficiency.
The Python script requires numpy, pandas and matplotlib; it regenerates the vector
figures, numerical LaTeX tables and the derived raw-reversal case check.

## Main reading cautions

Calibration stability is not measurement validity. The frozen audit reference is
another estimate of the proposed score, not a known true ability. Synthetic item
addition changes content and normalization. New rare-item simulations were designed
after inspecting the primary stress tests. Random split-half percentiles are not
confidence intervals for a reliability gain. No official ECPE pass score, CEFR
conversion, external validity advantage or demographic fairness result is claimed.

The current formula deliberately retains constant and negative-association items;
the report exposes the consequences rather than silently revising the method.

## Attribution

The response data and Q-matrix are derived from edmdata 1.3.0. Its package citation
is retained in `data/package_citation.txt`; the report cites the package and the
ECPE research literature. The original project source retains its source comments.
No new blanket license is imposed on third-party material by this package.
